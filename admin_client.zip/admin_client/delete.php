<?php
	if (isset($_GET["id"]) ){
		$id = $_GET["id"];

		$servername = "localhost";
		$username = "root";
		$password = "";
		$database = "admin_db";

		//create connection
		$connection = new mysqli($servername, $username, $password, $database);

		$sql = "DELETE FROM admin_client WHERE id=$id";
		$connection->query($sql);
	}

	header("location: /admin_client/index.php");
	exit;
?>